export default function App() {
  return (
    <div className="min-h-screen bg-[#0E4E4E] text-[#E4E6EC] flex flex-col items-center justify-center p-6">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold">Chris Kimau</h1>
        <p className="text-lg opacity-80">Supply Chain Specialist | Data Scientist</p>
        <a 
          href="mailto:kimauchris0@gmail.com"
          className="mt-4 inline-block bg-[#EE5914FF] px-6 py-2 rounded-xl text-white font-semibold hover:bg-orange-700"
        >
          Contact Me
        </a>
      </header>

      <section className="grid md:grid-cols-2 gap-8 max-w-4xl">
        <div className="bg-[#085BC9C1] p-6 rounded-2xl shadow-lg">
          <h2 className="text-2xl font-bold mb-4">About Me</h2>
          <p>
            I am a Supply Chain Specialist with over 6 years of experience in 
            inventory planning, demand forecasting, and data analytics.
            Skilled in SAP (MM, PP, SD), Python, SQL, and Power BI.
          </p>
        </div>

        <div className="bg-[#085BC9C1] p-6 rounded-2xl shadow-lg">
          <h2 className="text-2xl font-bold mb-4">Skills</h2>
          <ul className="list-disc list-inside space-y-2">
            <li>Demand Forecasting (ARIMA, Prophet, ML Models)</li>
            <li>Data Analytics (Python, Power BI, SQL)</li>
            <li>SAP MM, PP, SD Modules</li>
            <li>Inventory & Warehouse Management</li>
          </ul>
        </div>
      </section>
    </div>
  );
}
